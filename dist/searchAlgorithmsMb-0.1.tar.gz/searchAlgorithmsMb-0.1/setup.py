from setuptools import setup, find_packages

setup(
    name = "searchAlgorithmsMb",
    version= '0.1',
    packages = find_packages(),
    author = "Mrinmoy Borah",
    description = "A simple python library that includes two search algorithms: Linear Search and Binary Search"
)