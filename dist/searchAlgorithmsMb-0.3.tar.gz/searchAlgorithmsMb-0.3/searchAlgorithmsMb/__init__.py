from .BinarySearch import*
from .LinearSearch import*